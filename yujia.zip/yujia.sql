/*
 Navicat Premium Dump SQL

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80044 (8.0.44)
 Source Host           : localhost:3306
 Source Schema         : yujia

 Target Server Type    : MySQL
 Target Server Version : 80044 (8.0.44)
 File Encoding         : 65001

 Date: 09/07/2026 14:35:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for moment
-- ----------------------------
DROP TABLE IF EXISTS `moment`;
CREATE TABLE `moment`  (
  `moment_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '发布者ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `like_count` int NULL DEFAULT 0,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`moment_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of moment
-- ----------------------------
INSERT INTO `moment` VALUES (2, 12, '欢迎各位会员来到健身房', 1, '2026-07-06 15:58:39');
INSERT INTO `moment` VALUES (4, 12, '天天开心', 0, '2026-07-07 10:41:07');
INSERT INTO `moment` VALUES (5, 15, 'fff', 2, '2026-07-07 10:44:13');

-- ----------------------------
-- Table structure for moment_comment
-- ----------------------------
DROP TABLE IF EXISTS `moment_comment`;
CREATE TABLE `moment_comment`  (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `moment_id` bigint NOT NULL COMMENT '所属动态ID',
  `user_id` bigint NOT NULL COMMENT '评论者ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论者昵称（冗余）',
  `user_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论者头像（冗余）',
  `role_id` int NULL DEFAULT 0 COMMENT '评论者角色（冗余）',
  `is_anonymous` tinyint(1) NULL DEFAULT 0 COMMENT '是否匿名（0-实名，1-匿名）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论内容',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`) USING BTREE,
  INDEX `idx_moment`(`moment_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of moment_comment
-- ----------------------------
INSERT INTO `moment_comment` VALUES (3, 4, 12, 'xiongzheng', 'http://localhost:8081/LX/uploads/avatar/2026-07-07/3ab77f68efc240b8a3a6c71db333b2bb.png', 1, 1, '好', '2026-07-07 10:41:16');

-- ----------------------------
-- Table structure for moment_images
-- ----------------------------
DROP TABLE IF EXISTS `moment_images`;
CREATE TABLE `moment_images`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `moment_id` bigint NOT NULL,
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of moment_images
-- ----------------------------
INSERT INTO `moment_images` VALUES (1, 1, 'http://localhost:8081/LX/uploads/moment/2026/07/06/405dcf807ba943e6a0c9e5f1f3262da0.jpg');
INSERT INTO `moment_images` VALUES (2, 2, 'http://localhost:8081/LX/uploads/moment/2026/07/06/13dee4d3928342d1be865953767d0eea.jpg');
INSERT INTO `moment_images` VALUES (3, 3, 'http://localhost:8081/LX/uploads/moment/2026/07/07/9618ceaed4d545f5904ea92b9d9ebaa2.jpg');
INSERT INTO `moment_images` VALUES (4, 4, 'http://localhost:8081/LX/uploads/moment/2026/07/07/47fecb32737f4a2ab75d9643eb117337.jpg');
INSERT INTO `moment_images` VALUES (5, 4, 'http://localhost:8081/LX/uploads/moment/2026/07/07/c2c6b0a37d38498ebc385030c21b13af.jpg');
INSERT INTO `moment_images` VALUES (6, 4, 'http://localhost:8081/LX/uploads/moment/2026/07/07/1122cc5937334686999592515e37e6f2.jpg');
INSERT INTO `moment_images` VALUES (7, 4, 'http://localhost:8081/LX/uploads/moment/2026/07/07/92563800779e419b88219584d1ed6133.jpg');
INSERT INTO `moment_images` VALUES (8, 4, 'http://localhost:8081/LX/uploads/moment/2026/07/07/ef5b2c4c9be64685b0794583955cab56.jpg');
INSERT INTO `moment_images` VALUES (9, 5, 'http://localhost:8081/LX/uploads/moment/2026/07/07/6979d5f071634d6d8ab6d8d85152f347.jpg');

-- ----------------------------
-- Table structure for moment_like
-- ----------------------------
DROP TABLE IF EXISTS `moment_like`;
CREATE TABLE `moment_like`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `moment_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_moment_user`(`moment_id` ASC, `user_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of moment_like
-- ----------------------------
INSERT INTO `moment_like` VALUES (13, 2, 12, '2026-07-07 09:53:15');
INSERT INTO `moment_like` VALUES (14, 5, 15, '2026-07-07 10:44:16');
INSERT INTO `moment_like` VALUES (15, 5, 18, '2026-07-09 11:00:27');

-- ----------------------------
-- Table structure for yjx_course
-- ----------------------------
DROP TABLE IF EXISTS `yjx_course`;
CREATE TABLE `yjx_course`  (
  `course_id` int NOT NULL AUTO_INCREMENT COMMENT '课程ID，主键自增',
  `course_model` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '课程类型',
  `course_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '课程内容',
  `expect_status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '预期成果',
  `time_schedule` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '时间安排',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `coach_id` int NULL DEFAULT NULL COMMENT '教练ID，关联yjx_user表的user_id',
  `user_id` int NULL DEFAULT NULL COMMENT '创建者ID，关联yjx_user表的user_id',
  PRIMARY KEY (`course_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '课程表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yjx_course
-- ----------------------------
INSERT INTO `yjx_course` VALUES (1, '瑜伽', '基础瑜伽体式练习，呼吸控制', '提升柔韧性，缓解压力', '每周一、三、五 18:00-19:30', '2026-01-07 14:21:40', '2026-01-07 16:07:48', 3, 3);
INSERT INTO `yjx_course` VALUES (2, '游泳', '蛙泳基础教学，水中自救技巧', '掌握蛙泳，提高水性', '每周二、四、六 10:00-11:30', '2026-01-07 14:21:40', '2026-01-07 16:07:48', 3, 3);
INSERT INTO `yjx_course` VALUES (3, '举重', '力量训练，有氧运动', '增肌减脂，提升体能', '每天 19:00-20:30', '2026-01-07 14:21:40', '2026-01-08 09:22:28', 3, 3);
INSERT INTO `yjx_course` VALUES (5, '波比跳', '双手抱头，猛地一跳', '极大提高跳跃能力，有助于升高长高', '每周五 7：00 - 9：00', '2026-01-08 10:24:35', '2026-01-08 10:24:35', 4, 12);
INSERT INTO `yjx_course` VALUES (7, 'eqe', 'dqd2', 'dqdq2dfwd', 'dqq2', '2026-01-16 13:13:39', '2026-01-16 13:13:39', 3, 3);

-- ----------------------------
-- Table structure for yjx_equipment
-- ----------------------------
DROP TABLE IF EXISTS `yjx_equipment`;
CREATE TABLE `yjx_equipment`  (
  `equip_id` bigint NOT NULL AUTO_INCREMENT COMMENT '设备ID（主键）',
  `equip_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '设备名称',
  `equip_price` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '设备价格',
  `equip_use_year` int NULL DEFAULT 5 COMMENT '使用年限',
  `picture` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '设备图片',
  `equip_model` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '设备型号',
  `equip_brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '设备品牌',
  `purchase_date` date NULL DEFAULT NULL COMMENT '购买日期',
  `equip_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '正常' COMMENT '设备状态（正常、维修中、报废）',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `equip_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `equip_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`equip_id`) USING BTREE,
  INDEX `idx_equip_name`(`equip_name` ASC) USING BTREE,
  INDEX `idx_equip_status`(`equip_status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '设备信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yjx_equipment
-- ----------------------------
INSERT INTO `yjx_equipment` VALUES (1, '跑步机', 12500.00, 5, '../static/img/跑步机.png', 'TM-1000', '舒华', '2023-01-15', '正常', '2026-01-08 16:24:27', '用于有氧跑步运动，可调节速度与坡度', '臀部器械');
INSERT INTO `yjx_equipment` VALUES (2, '动感单车', 8500.00, 5, '../static/img/动感单车.png', 'SB-800', '乔山', '2023-03-20', '正常', '2026-01-08 16:24:27', '室内固定自行车，适合高强度间歇训练', '臀部器械');
INSERT INTO `yjx_equipment` VALUES (3, '史密斯机', 32000.00, 8, '../static/img/史密斯机.png', 'SM-300', '悍马', '2022-11-10', '维修中', '2026-01-08 16:24:27', '多功能力量训练器械，支持深蹲、卧推等', '胸部器械');
INSERT INTO `yjx_equipment` VALUES (4, '卧推架', 15000.00, 8, '../static/img/卧推架.png', 'BP-200', '泰诺健', '2026-07-03', '正常', '2026-01-08 16:24:27', '用于杠铃卧推，训练胸肌与上肢力量', '胸部器械');
INSERT INTO `yjx_equipment` VALUES (5, '椭圆机', 9800.00, 5, '../static/img/椭圆机.png', 'EL-500', '必确', '2023-04-18', '正常', '2026-01-08 16:24:27', '低冲击有氧器械，适合全身协调训练', '臀部器械');
INSERT INTO `yjx_equipment` VALUES (6, '哑铃套装', 12000.00, 10, '../static/img/哑铃套装.png', 'DS-100', '海德力', '2023-02-28', '报废', '2026-01-08 16:24:27', '可调节重量哑铃，适合自由重量训练', '肩部器械');
INSERT INTO `yjx_equipment` VALUES (7, '高位下拉器', 18000.00, 8, '../static/img/高位下拉器.png', 'LP-400', '力健', '2023-06-05', '正常', '2026-01-08 16:24:27', '训练背部肌肉，尤其是背阔肌', '背部器械');
INSERT INTO `yjx_equipment` VALUES (8, '瑜伽垫', 150.00, 0, '../static/img/瑜伽垫.png', 'YM-01', '李宁', '2026-07-01', '正常', '2026-01-08 16:24:27', '用于瑜伽、拉伸和地面训练', '肩部器械');

-- ----------------------------
-- Table structure for yjx_message
-- ----------------------------
DROP TABLE IF EXISTS `yjx_message`;
CREATE TABLE `yjx_message`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `verification_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '验证码',
  `user_id` int NULL DEFAULT NULL COMMENT '使用用户ID',
  `used` tinyint(1) NULL DEFAULT 0 COMMENT '是否已使用',
  `used_time` timestamp NULL DEFAULT NULL COMMENT '使用时间',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `expired_time` timestamp NULL DEFAULT NULL COMMENT '过期时间',
  `purpose` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'UPGRADE_GOLD' COMMENT '验证码用途',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `verification_code`(`verification_code` ASC) USING BTREE,
  INDEX `idx_code`(`verification_code` ASC) USING BTREE,
  INDEX `idx_user`(`user_id` ASC) USING BTREE,
  INDEX `idx_purpose`(`purpose` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '验证码表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yjx_message
-- ----------------------------
INSERT INTO `yjx_message` VALUES (1, 'GOLD1234', 7, 1, '2026-01-16 12:26:43', '2026-01-16 12:26:20', '2026-01-23 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (2, 'VIP2024A', 8, 1, '2026-01-16 13:10:41', '2026-01-16 12:26:20', '2026-01-31 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (3, 'UP888999', NULL, 0, NULL, '2026-01-16 12:26:20', '2026-02-15 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (4, 'USED5678', 5, 1, '2026-01-14 12:26:20', '2026-01-11 12:26:20', '2026-01-15 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (5, 'VIP2023B', 8, 1, '2026-01-06 12:26:20', '2025-12-27 12:26:20', '2026-01-11 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (6, 'EXPIRED99', NULL, 0, NULL, '2025-12-17 12:26:20', '2026-01-06 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (7, 'OLD2023C', NULL, 0, NULL, '2025-11-17 12:26:20', '2025-12-17 12:26:20', 'UPGRADE_GOLD');
INSERT INTO `yjx_message` VALUES (8, 'RESET123', NULL, 0, NULL, '2026-01-16 12:26:20', '2026-01-17 12:26:20', 'PASSWORD_RESET');
INSERT INTO `yjx_message` VALUES (9, 'ACTIVE77', NULL, 0, NULL, '2026-01-16 12:26:20', '2026-01-18 12:26:20', 'ACCOUNT_ACTIVATION');
INSERT INTO `yjx_message` VALUES (10, 'GOLD2024X', NULL, 0, NULL, '2026-01-16 12:26:20', '2027-01-16 12:26:20', 'UPGRADE_GOLD');

-- ----------------------------
-- Table structure for yjx_repair
-- ----------------------------
DROP TABLE IF EXISTS `yjx_repair`;
CREATE TABLE `yjx_repair`  (
  `repair_id` bigint NOT NULL AUTO_INCREMENT COMMENT '维修ID（主键）',
  `repair_request_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '报修单号（唯一）',
  `equip_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '设备类型',
  `repair_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '维修描述',
  `repair_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '待处理' COMMENT '维修状态',
  `user_id` bigint NOT NULL COMMENT '用户ID（外键，关联user表）',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `assigned_technician_id` bigint NULL DEFAULT NULL COMMENT '指派的维修技师ID',
  `repair_cost` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '维修费用',
  `repair_start_time` datetime NULL DEFAULT NULL COMMENT '维修开始时间',
  `repair_end_time` datetime NULL DEFAULT NULL COMMENT '维修完成时间',
  `estimated_completion` datetime NULL DEFAULT NULL COMMENT '预计完成时间',
  `priority_level` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '一般' COMMENT '优先级',
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `contact_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系人',
  `location` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '设备位置',
  `is_urgent` tinyint(1) NULL DEFAULT 0 COMMENT '是否紧急（0-否，1-是）',
  `is_deleted` tinyint(1) NULL DEFAULT 0 COMMENT '是否删除（0-未删除，1-已删除）',
  `deleted_at` datetime NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`repair_id`) USING BTREE,
  UNIQUE INDEX `uk_repair_request_id`(`repair_request_id` ASC) USING BTREE,
  INDEX `idx_user_id`(`user_id` ASC) USING BTREE,
  INDEX `idx_repair_status`(`repair_status` ASC) USING BTREE,
  INDEX `idx_created_at`(`created_at` ASC) USING BTREE,
  INDEX `idx_technician_id`(`assigned_technician_id` ASC) USING BTREE,
  INDEX `idx_priority`(`priority_level` ASC) USING BTREE,
  INDEX `idx_is_urgent`(`is_urgent` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '维修记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yjx_repair
-- ----------------------------
INSERT INTO `yjx_repair` VALUES (1, 'RQ202401080001', '跑步机-型号A', '电机故障，无法启动', '已完成', 3, '2026-01-08 14:19:26', '2026-01-15 22:22:09', 5, 500.00, NULL, NULL, NULL, '紧急', '13800138001', NULL, '器械区A区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (2, 'RQ202401080002', '动感单车-型号B', '脚踏板松动，有异响', '处理中', 4, '2026-01-08 14:19:26', '2026-01-08 14:26:19', 6, 120.00, NULL, NULL, NULL, '高', '13800138002', NULL, '有氧区B区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (3, 'RQ202401080003', '哑铃架', '支架断裂，无法放置哑铃', '待处理', 4, '2026-01-08 14:19:26', '2026-01-08 14:19:26', NULL, 0.00, NULL, NULL, NULL, '一般', '13800138003', NULL, '力量区C区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (4, 'RQ202401080004', '史密斯机', '滑轨卡顿，需要润滑', '已完成', 5, '2026-01-08 14:19:26', '2026-01-15 21:15:40', 5, 80.00, NULL, NULL, NULL, '一般', '13800138004', NULL, '力量区D区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (5, 'RQ202401080005', '椭圆机', '显示屏不亮，按键无反应', '处理中', 4, '2026-01-08 14:19:26', '2026-01-08 14:26:19', 6, 300.00, NULL, NULL, NULL, '高', '13800138005', NULL, '有氧区E区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (6, 'RQ202401080006', '瑜伽垫架', '轮子损坏，无法移动', '待处理', 5, '2026-01-08 14:19:26', '2026-01-08 14:26:19', NULL, 150.00, NULL, NULL, NULL, '一般', '13800138006', NULL, '瑜伽室F区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (7, 'RQ202401080007', '力量训练器', '钢丝绳断裂，需要更换', '处理中', 5, '2026-01-08 14:19:26', '2026-01-08 14:26:19', 5, 450.00, NULL, NULL, NULL, '紧急', '13800138007', NULL, '力量训练区', 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (12, 'RQ202601150001', '动感单车', 'ss', '待处理', 12, '2026-01-15 20:23:05', '2026-01-15 22:41:24', NULL, 0.00, NULL, NULL, NULL, '一般', NULL, NULL, NULL, 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (13, 'RQ202601160001', '卧推架', 'ddda', '待处理', 1, '2026-01-16 13:04:32', '2026-07-02 10:45:02', NULL, 0.00, NULL, NULL, NULL, '一般', NULL, NULL, NULL, 0, 0, NULL);
INSERT INTO `yjx_repair` VALUES (14, 'RQ202607090001', '卧推架', 'fef', '待处理', 18, '2026-07-09 10:59:51', '2026-07-09 10:59:58', NULL, 0.00, NULL, NULL, NULL, '一般', NULL, NULL, NULL, 0, 0, NULL);

-- ----------------------------
-- Table structure for yjx_repair_images
-- ----------------------------
DROP TABLE IF EXISTS `yjx_repair_images`;
CREATE TABLE `yjx_repair_images`  (
  `image_id` bigint NOT NULL AUTO_INCREMENT COMMENT '图片ID',
  `repair_id` bigint NOT NULL COMMENT '维修ID',
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图片URL',
  `image_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '图片原始文件名',
  `file_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '服务器存储路径',
  `file_size` bigint NULL DEFAULT NULL COMMENT '文件大小（字节）',
  `file_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '文件类型',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `is_deleted` tinyint NULL DEFAULT 0 COMMENT '逻辑删除标志(0-未删除,1-已删除)',
  PRIMARY KEY (`image_id`) USING BTREE,
  INDEX `idx_repair_id`(`repair_id` ASC) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted` ASC) USING BTREE,
  CONSTRAINT `fk_repair_images_repair` FOREIGN KEY (`repair_id`) REFERENCES `yjx_repair` (`repair_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '维修图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yjx_repair_images
-- ----------------------------
INSERT INTO `yjx_repair_images` VALUES (1, 12, 'http://localhost:8081/LX/uploads/repair/2026/01/15/163a57427ff84d9ca0bc7c24c0f770d6.png', '屏幕截图 2026-01-11 104031.png', 'repair/2026/01/15/163a57427ff84d9ca0bc7c24c0f770d6.png', 32399, 'image/png', '2026-01-15 22:41:22', 0);
INSERT INTO `yjx_repair_images` VALUES (2, 13, 'http://localhost:8081/LX/uploads/repair/2026/01/16/fcb2440e7bd6470aad8bc59494e7c0ac.png', '屏幕截图 2026-01-11 104031.png', 'repair/2026/01/16/fcb2440e7bd6470aad8bc59494e7c0ac.png', 32399, 'image/png', '2026-01-16 13:04:41', 0);
INSERT INTO `yjx_repair_images` VALUES (3, 13, 'http://localhost:8081/LX/uploads/repair/2026/01/16/1bd103ff403a4b1bbad8dfc01408a15a.jpg', 'QQ图片20231027184949.jpg', 'repair/2026/01/16/1bd103ff403a4b1bbad8dfc01408a15a.jpg', 293762, 'image/jpeg', '2026-01-16 22:09:15', 0);
INSERT INTO `yjx_repair_images` VALUES (4, 13, 'http://localhost:8081/LX/uploads/repair/2026/07/02/cef3c12871f642208a2ac4d9acb06a8f.png', '屏幕截图 2026-07-01 140213.png', 'repair/2026/07/02/cef3c12871f642208a2ac4d9acb06a8f.png', 207818, 'image/png', '2026-07-02 10:45:01', 0);
INSERT INTO `yjx_repair_images` VALUES (5, 14, 'http://localhost:8081/LX/uploads/repair/2026/07/09/acb5565e851b477d8dd377209516a496.png', '屏幕截图 2026-06-28 220030.png', 'repair/2026/07/09/acb5565e851b477d8dd377209516a496.png', 3365130, 'image/png', '2026-07-09 10:59:56', 0);

-- ----------------------------
-- Table structure for yjx_user
-- ----------------------------
DROP TABLE IF EXISTS `yjx_user`;
CREATE TABLE `yjx_user`  (
  `user_id` int NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `user_password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码哈希',
  `role_id` int NOT NULL COMMENT '角色ID',
  `user_bio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '个人简介',
  `user_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '手机号',
  `user_gender` enum('male','female','unknown') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'unknown' COMMENT '性别',
  `user_last_active` datetime NULL DEFAULT NULL COMMENT '最后活跃',
  `user_created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `user_status` enum('active','inactive','banned','pending') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'active' COMMENT '状态',
  `real_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '真实姓名',
  `birth_date` date NULL DEFAULT NULL COMMENT '生日',
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '所在地',
  `user_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '用户头像URL',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yjx_user
-- ----------------------------
INSERT INTO `yjx_user` VALUES (1, 'admin', 'admin@yujia.com', '81e3f51d425d1063efc98bb01c44eeac', 1, '系统管理员，负责维护整个系统的运行', '13800138000', 'male', '2026-01-06 10:28:34', '2026-01-02 00:26:25', 'active', '张伟', '1985-05-15', '北京市朝阳区', '');
INSERT INTO `yjx_user` VALUES (2, 'reception1', 'reception1@yujia.com', 'e10adc3949ba59abbe56e057f20f883e', 2, '热情周到的前台接待员，为客户提供优质服务', '13800138001', 'female', '2024-01-01 10:15:00', '2026-01-02 00:26:25', 'active', '李晓芳', '1993-08-22', '上海市浦东新区', '');
INSERT INTO `yjx_user` VALUES (3, '王五教练', 'tech1@yujia.com', '81e3f51d425d1063efc98bb01c44eeac', 3, '专业健身教练，拥有8块腹肌', '13800138002', 'male', '2026-01-16 12:14:47', '2026-01-02 00:26:25', 'banned', '王刚', '1990-11-30', '深圳市福田区', '');
INSERT INTO `yjx_user` VALUES (4, '刘一教练', 'tech2@yujia.com', '81e3f51d425d1063efc98bb01c44eeac', 3, '擅长进行有氧呼吸训练，拥有一个月速成法', '13800138003', 'male', '2026-01-16 13:07:51', '2026-01-02 00:26:25', 'active', '刘强', '1988-03-25', '广州市天河区', '');
INSERT INTO `yjx_user` VALUES (5, 'customer1', 'customer1@yujia.com', 'e10adc3949ba59abbe56e057f20f883e', 5, '健身爱好者，经常健身', '13800138004', 'male', '2024-01-01 11:10:00', '2026-01-02 00:26:25', 'active', '赵明', '1995-02-14', '杭州市西湖区', '');
INSERT INTO `yjx_user` VALUES (6, 'customer2', 'customer2@yujia.com', 'e10adc3949ba59abbe56e057f20f883e', 5, '马拉松狂热者', '13800138005', 'female', '2024-01-01 13:25:00', '2026-01-02 00:26:25', 'active', '陈静', '1998-07-08', '南京市鼓楼区', '');
INSERT INTO `yjx_user` VALUES (7, 'customer3', 'customer3@yujia.com', '81e3f51d425d1063efc98bb01c44eeac', 5, '喜欢尝试新东西，以体验为主', '13800138006', 'female', '2026-01-16 12:16:21', '2026-01-02 00:26:25', 'active', '杨婷婷', '2000-01-20', '成都市武侯区', '');
INSERT INTO `yjx_user` VALUES (8, 'customer4', 'customer4@yujia.com', '81e3f51d425d1063efc98bb01c44eeac', 5, '学生用户', '13800138007', 'male', '2026-01-16 13:09:36', '2026-01-02 00:26:25', 'active', '周浩', '2002-09-12', '武汉市江汉区', '');
INSERT INTO `yjx_user` VALUES (9, 'customer5', 'customer5@yujia.com', 'e10adc3949ba59abbe56e057f20f883e', 5, '商务人士，工作很忙，但还是想训练出成效', '13800138008', 'male', '2024-01-01 14:50:00', '2026-01-02 00:26:25', 'active', '吴磊', '1987-06-18', '西安市雁塔区', '');
INSERT INTO `yjx_user` VALUES (10, 'customer6', 'customer6@yujia.com', 'e10adc3949ba59abbe56e057f20f883e', 5, '老客户，信任我们的条件', '13800138009', 'female', '2024-01-01 17:05:00', '2026-01-02 00:26:25', 'active', '林晓雨', '1996-04-03', '重庆市渝中区', '');
INSERT INTO `yjx_user` VALUES (11, 'finance1', 'finance@yujia.com', 'e10adc3949ba59abbe56e057f20f883e', 6, '负责公司的财务管理和结算工作', '13800138011', 'female', '2024-01-01 10:00:00', '2026-01-02 00:26:25', 'active', '郑秀英', '1989-10-28', '长沙市岳麓区', '');
INSERT INTO `yjx_user` VALUES (12, 'xiongzheng', 'xzjob@xxx.com', '349a97b8e1f6735c491421cb486a0a56', 1, '系统管理员，负责维护整个系统的运行', '18684692155', 'male', '2026-07-02 10:44:12', '2026-01-05 16:04:14', 'active', '熊征', '1982-11-11', '长沙市岳麓区', 'http://localhost:8081/LX/uploads/avatar/2026-07-07/3ab77f68efc240b8a3a6c71db333b2bb.png');
INSERT INTO `yjx_user` VALUES (14, '11', '12', 'f74595b7a43f4f779e5124d8e348f0d7', 4, NULL, NULL, 'unknown', NULL, '2026-01-15 13:24:12', 'banned', NULL, NULL, NULL, '');
INSERT INTO `yjx_user` VALUES (15, 'LLLL', '3243750959@qq.com', '16a39733bb4f214bc7aeef3fed9b3877', 4, NULL, NULL, 'unknown', NULL, '2026-07-07 10:42:37', 'active', NULL, NULL, NULL, '');
INSERT INTO `yjx_user` VALUES (17, 'LLLLL', '3343750959@qq.com', '349a97b8e1f6735c491421cb486a0a56', 4, NULL, NULL, 'unknown', NULL, '2026-07-09 10:51:23', 'active', NULL, NULL, NULL, '');
INSERT INTO `yjx_user` VALUES (18, 'xw', '3243750949@qq.com', '349a97b8e1f6735c491421cb486a0a56', 4, NULL, NULL, 'unknown', NULL, '2026-07-09 10:57:14', 'active', NULL, NULL, NULL, '');

SET FOREIGN_KEY_CHECKS = 1;
